package com.yahoo.weather.client.data.unit;


public enum WeekDay {
	MON,
	TUE,
	WED,
	THU,
	FRI,
	SAT,
	SUN;
}
