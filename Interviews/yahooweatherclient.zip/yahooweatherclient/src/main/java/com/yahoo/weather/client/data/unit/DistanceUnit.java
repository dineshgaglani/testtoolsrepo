/**
 * 
 */
package com.yahoo.weather.client.data.unit;


public enum DistanceUnit {
	
	/**
	 * Miles.
	 */
	MI,
	
	/**
	 * Kilometers.
	 */
	KM;
}
