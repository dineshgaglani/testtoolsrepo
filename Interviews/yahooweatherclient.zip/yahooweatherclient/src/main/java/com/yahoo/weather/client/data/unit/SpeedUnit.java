/**
 * 
 */
package com.yahoo.weather.client.data.unit;

public enum SpeedUnit {
	
	/**
	 * Miles per hour. 
	 */
	MPH,
	
	/**
	 * Kilometers per hour. 
	 */
	KMH;
}
