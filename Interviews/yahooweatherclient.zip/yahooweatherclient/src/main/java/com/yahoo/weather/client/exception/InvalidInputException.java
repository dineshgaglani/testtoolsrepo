package com.yahoo.weather.client.exception;

/**
 * Created by dgaglani on 6/3/14.
 */
public class InvalidInputException extends Exception {

    public InvalidInputException(String s) {
        super(s);
    }
}
