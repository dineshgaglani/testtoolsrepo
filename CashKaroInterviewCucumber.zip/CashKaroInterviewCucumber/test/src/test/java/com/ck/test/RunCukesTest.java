package com.ck.test;

import org.junit.runner.RunWith;

import cucumber.api.junit.Cucumber;

/**
 * Created by dgaglani on 11/7/14.
 */
@RunWith(Cucumber.class)
public class RunCukesTest {
}
